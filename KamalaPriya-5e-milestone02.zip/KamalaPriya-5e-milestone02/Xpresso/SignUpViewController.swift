//
//  SignUpViewController.swift
//  Xpresso
//
//  Created by Bharam,Kamala Priya on 4/1/17.
//  Copyright © 2017 Bharam,Kamala Priya. All rights reserved.
//

import UIKit
import Parse

class SignUpViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func SignUp(_ sender: Any) {
        
 
        let user = PFUser()
        
        user.username = Username.text!
        
        user.password = pwd.text!
        
        user.email = Email.text!
        
        // Signing up using the Parse API
        
        user.signUpInBackground( block: {
            
            (success, error) -> Void in
            
            if let error = error as NSError? {
                
                let errorString = error.userInfo["error"] as? NSString
                
                // In case something went wrong, use errorString to get the error
                
                self.displayAlertWithTitle("Something has gone wrong", message:"\(errorString)")
                
            } else {
                
                // Everything went okay
                
                self.displayAlertWithTitle("Success!", message:"Registration was successful")
                
                
                
                
                
                let emailVerified = user["emailVerified"]
                
                if emailVerified != nil && (emailVerified as! Bool) == true {
                    
                    // Everything is fine
                    
                }
                    
                else {
                    
                    // The email has not been verified, so logout the user
                    
                    PFUser.logOut()
                    
                }
                
            }
            
        })
        
    }
            func displayAlertWithTitle(_ title:String, message:String){
        let alert:UIAlertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let defaultAction:UIAlertAction =  UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(defaultAction)
        self.present(alert, animated: true, completion: nil)
        
    }
    
    
    @IBOutlet weak var FName: UITextField!
    
    @IBOutlet weak var LName: UITextField!
    
    @IBOutlet weak var Email: UITextField!
    
    @IBOutlet weak var Username: UITextField!
    
    @IBOutlet weak var pwd: UITextField!
    
    @IBOutlet weak var npwd: UITextField!
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
